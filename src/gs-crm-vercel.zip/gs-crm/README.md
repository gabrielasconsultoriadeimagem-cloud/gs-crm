# GS Estratégia e Imagem — CRM Interno

## 🚀 Como publicar na Vercel (GRÁTIS)

### Passo 1: Criar conta na Vercel
1. Acesse **https://vercel.com**
2. Clique em **"Sign Up"**
3. Crie a conta com seu **GitHub**, **GitLab** ou **e-mail**

### Passo 2: Instalar Vercel CLI (opcional, mais fácil pelo site)
Se quiser fazer pelo site, pule para o Passo 3.

```bash
npm install -g vercel
cd gs-crm
npm install
vercel
```

### Passo 3: Deploy pelo site (mais fácil)
1. Acesse **https://vercel.com/new**
2. Clique em **"Upload"** (ícone de pasta)
3. Arraste a pasta **gs-crm** inteira para lá
4. A Vercel detecta automaticamente que é um projeto Vite/React
5. Clique em **"Deploy"**
6. Em ~1 minuto você recebe o link! Ex: `gs-crm.vercel.app`

### Passo 4: Domínio personalizado (opcional)
- Na Vercel, vá em **Settings > Domains**
- Adicione `crm.gsestrategia.com.br` (se tiver domínio)

---

## 🔑 Logins Padrão

| Nome      | E-mail                      | Senha            | Perfil       |
|-----------|----------------------------|------------------|--------------|
| Gabriela  | gabrielasuanad@gmail.com   | 22832329Gabi@    | Sócio        |
| Sarah     | sarah@gs.com               | gs2025           | Comercial    |
| Ana       | ana@gs.com                 | gs2025           | Consultoria  |
| Lucas     | lucas@gs.com               | gs2025           | Produção     |
| Marina    | marina@gs.com              | gs2025           | Marketing    |

---

## 📌 Importante

- Os dados são salvos no **localStorage** do navegador de cada pessoa
- Cada navegador/dispositivo tem seus próprios dados
- Se limpar os dados do navegador, volta ao estado inicial
- Para um CRM com dados compartilhados entre todos, seria necessário um banco de dados (upgrade futuro)

---

## 🔒 Perfis de Acesso

| Perfil       | Acessa                                          |
|-------------|------------------------------------------------|
| Sócio       | Tudo + Aprovar contas novas                     |
| Comercial   | Dashboard, Comercial, Tarefas                   |
| Consultoria | Consultoria, Tarefas                            |
| Marketing   | Produção, Tarefas                               |
| Produção    | Produção, Tarefas                               |

## 📋 Pipeline de Consultoria (18 etapas)

1. Clientes
2. Análise Inicial
3. Visagismo
4. Biótipo / Tipologia Física
5. Análise de Estilo
6. Apresentação Estratégica
7. Apresentação do Dossiê Estratégico
8. Apresentação de Guia de Medidas
9. Análise de Guarda-Roupa (Online)
10. Análise de Guarda-Roupa (Presencial)
11. Análise de Peças por Foto
12. Personal Shopping
13. Curadoria de Peças
14. Etiqueta e Comportamento
15. Análise Olfativa
16. Montagem de Looks
17. Sessão de Fotos
18. Finalizados
